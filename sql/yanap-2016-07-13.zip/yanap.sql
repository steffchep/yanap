-- --------------------------------------------------------
-- Host:                         de-mssql2012n
-- Server Version:               11.0.6020.0
-- Server Betriebssystem:        Windows NT 6.3 <X64> (Build 9600: ) (Hypervisor)
-- HeidiSQL Version:             9.1.0.4867
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES  */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
-- Exportiere Daten aus Tabelle stephaniep_yanap.sprints: -1 rows
/*!40000 ALTER TABLE "sprints" DISABLE KEYS */;
REPLACE INTO "sprints" ("id", "name", "startDate", "endDate", "status", "team", "pointsplanned", "pointscompleted") VALUES
	(1, '2 Turds of a Sprint', '2016-05-24', '2016-06-07', 3, 'Abraxas', 21, 28),
	(2, 'Superturd!', '2016-06-07', '2016-06-21', 3, 'Abraxas', 44, 26),
	(3, 'Revenge of the Superturd', '2016-06-21', '2016-07-05', 3, 'Abraxas', 26, 37),
	(4, 'We''ve had worse!', '2016-07-05', '2016-07-19', 2, 'Abraxas', 0, 0),
	(10002, '[next]... or have we?', '2016-07-19', '2016-08-02', 1, 'Abraxas', 0, 0);
/*!40000 ALTER TABLE "sprints" ENABLE KEYS */;

-- Exportiere Daten aus Tabelle stephaniep_yanap.users: -1 rows
/*!40000 ALTER TABLE "users" DISABLE KEYS */;
REPLACE INTO "users" ("id", "name", "isDeveloper", "team") VALUES
	(1, 'Dawid', 'True', 'Abraxas'),
	(2, 'Jana', 'True', 'Abraxas'),
	(3, 'Jessica', 'True', 'Abraxas'),
	(4, 'Michael', 'True', 'Abraxas'),
	(5, 'Rauf', 'True', 'Abraxas'),
	(6, 'Steffi', 'True', 'Abraxas'),
	(7, 'Phil', 'False', ''),
	(8, 'Tom', 'False', ''),
	(9, 'Anna', 'True', 'Elwetritsch'),
	(10, 'Bernd', 'True', 'Elwetritsch'),
	(11, 'Peter', 'True', 'Elwetritsch'),
	(12, 'Sven', 'True', 'Elwetritsch'),
	(13, 'Sebastian', 'True', 'Elwetritsch'),
	(14, 'Dennis', 'False', 'Elwetritsch'),
	(17, 'Joachim', 'True', 'Moby'),
	(18, 'Jan-Fabian', 'True', 'Moby'),
	(19, 'Corinna', 'True', 'Moby'),
	(20, 'Toby', 'True', 'Moby'),
	(21, 'Indrek', 'True', 'Moby'),
	(10002, 'Robbert-Jan', 'False', '');
/*!40000 ALTER TABLE "users" ENABLE KEYS */;

-- Exportiere Daten aus Tabelle stephaniep_yanap.usersbysprint: -1 rows
/*!40000 ALTER TABLE "usersbysprint" DISABLE KEYS */;
REPLACE INTO "usersbysprint" ("id", "userid", "sprintid", "day01", "day02", "day03", "day04", "day05", "day06", "day07", "day08", "day09", "day10") VALUES
	(1, 1, 1, 0.5, 1, 2, 2, 1, 1, 1, 1, 1, 1),
	(2, 2, 1, 0.5, 1, 2, 2, 2, 2, 2, 2, 2, 2),
	(3, 3, 1, 2, 2, 2, 2, 0.5, 1, 1, 1, 1, 1),
	(4, 4, 1, 2, 2, 2, 2, 0.5, 1, 1, 1, 1, 1),
	(5, 5, 1, 0.5, 1, 2, 3, 1, 1, 1, 1, 1, 1),
	(6, 6, 1, 0.5, 1, 2, 2, 1, 1, 1, 1, 1, 1),
	(7, 7, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1),
	(8, 8, 1, 1, 1, 2, 1, 1, 1, 2, 1, 1, 1),
	(9, 1, 2, 1, 0.5, 0.5, 3, 1, 1, 1, 1, 1, 1),
	(10, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1),
	(11, 3, 2, 1, 1, 0.5, 3, 4, 1, 1, 1, 1, 0.5),
	(12, 4, 2, 1, 1, 1, 3, 0.5, 3, 3, 3, 1, 1),
	(13, 5, 2, 1, 1, 0.5, 3, 1, 1, 1, 1, 1, 1),
	(14, 6, 2, 1, 3, 3, 3, 1, 1, 1, 1, 2, 2),
	(15, 7, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
	(16, 8, 2, 1, 1, 3, 0.5, 1, 1, 1, 1, 1, 1),
	(17, 1, 3, 0.5, 1, 1, 3, 1, 0.5, 1, 1, 1, 1),
	(18, 2, 3, 3, 1, 1, 2, 1, 3, 1, 1, 1, 3),
	(19, 3, 3, 1, 1, 1, 3, 0.5, 1, 1, 1, 1, 4),
	(20, 4, 3, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1),
	(21, 5, 3, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1),
	(22, 6, 3, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1),
	(23, 7, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
	(24, 8, 3, 0.5, 1, 0.5, 1, 1, 1, 1, 1, 1, 1),
	(25, 1, 4, 1, 1, 0.5, 3, 1, 1, 1, 1, 1, 1),
	(26, 2, 4, 0.5, 1, 1, 3, 1, 1, 1, 3, 1, 1),
	(27, 3, 4, 1, 1, 0.5, 3, 0.5, 1, 1, 1, 1, 0.5),
	(28, 4, 4, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1),
	(29, 7, 4, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1),
	(30, 5, 4, 2, 1, 0.5, 3, 1, 1, 1, 1, 1, 1),
	(31, 6, 4, 1, 1, 0.5, 3, 1, 1, 1, 1, 1, 2),
	(32, 8, 4, 2, 0.5, 1, 3, 1, 1, 1, 1, 1, 1),
	(10002, 1, 10002, 0.5, 1, 1, 3, 1, 1, 1, 1, 1, 1),
	(10003, 2, 10002, 0.5, 1, 1, 3, 1, 0.5, 1, 1, 1, 2),
	(10004, 3, 10002, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
	(10005, 4, 10002, 1, 1, 1, 2, 2, 2, 2, 0.5, 1, 1),
	(10006, 5, 10002, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1),
	(10007, 10002, 10002, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
	(10008, 6, 10002, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0.5),
	(10009, 8, 10002, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
/*!40000 ALTER TABLE "usersbysprint" ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
